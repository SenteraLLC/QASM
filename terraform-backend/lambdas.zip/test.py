def test(event, context):
    """Test."""
    print("wahoo")